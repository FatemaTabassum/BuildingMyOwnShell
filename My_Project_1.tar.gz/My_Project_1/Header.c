//
//  Header.c
//  BuildingShell
//
//  Created by Fatema on 10/1/19.
//  Copyright © 2019 Liza. All rights reserved.
//

#include "Header.h"


bool should_exit_shell = false;

