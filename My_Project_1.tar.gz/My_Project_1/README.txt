Introduction:

mybash is a unix shell written in C. This document describes its funtionality and presents user interactions with the program that covers all the requirements of the course.
The code is written for the course COP5570. 
 

Name:

the name "mybash-1.1" will appear before every input from user.


The project folder:

The project folder contain total 10 files. These are:

    1.  main.c
    2.  Parser.c
    3.  Parser.h
    4.  ExecuteCommand.c
    5.  ExecuteCommand.h
    6.  Header.c
    7.  Header.h
    8.  MyLsImplement.c
    9.  Makefile
    10. README

Compile:

in order to compile, go to the directory where this project resides using cd command. Then type "make" command to create mybash and myls.

Run

type ./mybash to run the program from the directory where the project resides.

Input:

The program takes input from user through standard-input or file and shows output to either standard-output or file according to the command.

Functionalities and User interactions

 1. built-in commands such as: exit, cd, pwd
	
	Sample Test Cases:
        1. cd ~
        2. cd ~/
        3. cd .. / ..
        4. cd ..

 2. In the case of set command, "set MYPATH=path" is supported
	
	Sample Test Cases:
        1. set MYPATH=/Users/usname

 3. One external command myls is implemented. After setting MYPATH (set=MYPATH), you have to copy and paste the myls executable in MYPATH in order to run it. You can run it without setting MYPATH as well. In that case myls must be in  the current working directory.
	
	Sample Test Cases:
        1. myls -l /Users/liz/file2.txt
        2. myls -l f2.txt
        3. myls
        4. myls -l -a f2.txt
        5. myls -l -a /Users/liz



 4. Please be careful while you enter a directory. A directory path containing whitespace characters may or may not  work.

 5. The program will end when user type exit , or press CTRL-D.

 6. All existing external commands are supported.

 7. pipe commands are implemented and works properly for multiple commands (commands may have parameters).

	Sample Test Cases:

        1 ls -l f.txt | sort | cat
        2 myls -l f.txt | sort | cat
        3 pwd | cat
       
 8. i/o redirections are supported (commands may have parameters).

	Sample Test Cases:

        1 sort < file1.txt > file2.txt
        2 ls -l > file2.txt
        3 sort < file2.txt
        4 cat < /Users/liza/Desktop/file2.txt
	
 9. No background processes are supported
