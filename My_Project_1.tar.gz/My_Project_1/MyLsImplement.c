//
//  MyLsImplement.c
//  MylsImplement
//
//  Created by Fatema on 10/13/19.
//  Copyright © 2019 Liza. All rights reserved.
//

#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <stdbool.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include <signal.h>

#define DIRMODE
#define CUR_DIR "."
#define FIRST_COMMAND_NO 1
#define ARGUMENTS_COMMAND '-'
#define DIRECTORY_ 1
#define FILE_ 0
#define FILE_PERM_SIZE 20

struct stat buffer;
char curr_working_dir[1025];
char str[1024];

char * cur;

char *filename;

typedef struct ls_command_format_specifier {
    bool is_ls_command;
    bool show_hidden_file;
    bool is_list_all_file;
    bool is_directory;
    bool is_file;
    bool is_valid_format;
    char* path;
} cmd_format_specifier;

void open_dir(cmd_format_specifier *format_specifier);
void get_current_working_directory(void);
void print_directory(DIR* dr, cmd_format_specifier *format_specifier);
void set_initial_values(cmd_format_specifier* format_specifier);
bool is_a_Valid_Path(const char *path);
void print_file_stat(char full_path[], char * dname);
char *  get_username_val(uid_t uid);
char *  get_groupname_val(gid_t gid);
void signal_handler(int sig);
void join_signal(void);
void print_only_dir_filenames(DIR *dr, cmd_format_specifier *format_specifier);
void go_to_absolute_path(cmd_format_specifier *format_specifier);
void go_to_current_path(cmd_format_specifier *format_specifier);
void open_and_check_dir(char *filename,cmd_format_specifier *format_specifier , char *full_path);

int main(int argc, const char * argv[]) {
//int main(){
    cmd_format_specifier format_specifier;
    set_initial_values(&format_specifier);
    join_signal();
    if (argc < 1) {
        fprintf(stderr, "Usage: myls <pathname>\n");
        exit(EXIT_FAILURE);
    }

    for (int i = FIRST_COMMAND_NO; i < argc; i++) {
        if (i == FIRST_COMMAND_NO && (strcmp(argv[i], "ls") == 0)) {
            format_specifier.is_ls_command = true;
        } else if (i > FIRST_COMMAND_NO && strcmp(argv[i], "-a") == 0) {
            format_specifier.show_hidden_file = true;
        } else if (i > FIRST_COMMAND_NO && strcmp(argv[i], "-l") == 0) {
            format_specifier.is_list_all_file = true;
        }
        
        if (i > FIRST_COMMAND_NO &&
            i == (argc - 1) &&
            argv[i][0] != ARGUMENTS_COMMAND) {
            format_specifier.is_directory = true;
            format_specifier.path = (char *) malloc(1024 * sizeof(char));
            format_specifier.path = (char *)argv[i];
        }
        if (argv[i][0] != ARGUMENTS_COMMAND) {
            if ((strcmp(argv[i], "ls") != 0 && i < (argc -1))) {
                format_specifier.is_valid_format = true;
            }
        }
    }
    
    if (format_specifier.is_ls_command == true &&
        format_specifier.is_valid_format == true &&
        format_specifier.is_directory == false) {
        get_current_working_directory();
        format_specifier.path = cur;
    }
//    for (int i = 0; i<argc; i++) {
//        printf("argv[%d]: %s\n", i, argv[i]);
//    }
//    printf("\n\n\n");
//    printf("format_specifier.is_directory = %d\n", format_specifier.is_directory);
//    printf("format_specifier.is_list_all_file = %d\n", format_specifier.is_list_all_file);
//    printf("format_specifier.show_hidden_file = %d\n", format_specifier.show_hidden_file);
//    printf("format_specifier.is_ls_command = %d\n", format_specifier.is_ls_command);
//    printf("format_specifier.is_valid_format = %d\n", format_specifier.is_valid_format);
//
    
    
    open_dir(&format_specifier);
    exit(EXIT_SUCCESS);
}

void get_current_working_directory(void) {
    cur = getcwd(curr_working_dir, sizeof(curr_working_dir));
    if (cur == NULL) {
        perror("cur directory");
        exit(EXIT_FAILURE);
    }
    //printf("(%s)", curr_working_dir);
    return ;
}


void open_dir(cmd_format_specifier *format_specifier) {
    if (format_specifier->is_valid_format == true) {
        
        DIR *dr = opendir(format_specifier->path);
        if (dr == NULL)
            {
                format_specifier->is_directory = false;
                //printf("format_specifier.is_directory = %d\n", format_specifier->is_directory);

                if (format_specifier->path[0] == '/') {
                    go_to_absolute_path(format_specifier);
                } else {
                    go_to_current_path(format_specifier);
                }
                //perror("Could not open current directory" );
            } else {
                if (format_specifier->is_ls_command &&
                    format_specifier->is_valid_format &&
                    !format_specifier->is_list_all_file) {
                    print_only_dir_filenames(dr, format_specifier);
                }
                print_directory(dr, format_specifier);
                closedir(dr);
            }
    }
}

void go_to_absolute_path(cmd_format_specifier *format_specifier) {
    char *full_path = strdup(format_specifier->path);
    int len = (int)strlen(format_specifier->path);
    int indx = 0;
    for (int i = len -1; i > -1; i--) {
        if (format_specifier->path[i] == '/') {
            break;
        }
        indx++;
    }
    filename = (char*) malloc((indx + 5) * sizeof(char));
    int j = 0;
    for (int i = len - indx; i < len; i++) {
        filename[j++] = format_specifier->path[i];
    }
    strncpy(str, format_specifier->path, len-indx);
    str[strlen(str) - 1] = '\0';
    format_specifier->path = str;
    filename[j] = '\0';
    open_and_check_dir(filename, format_specifier, full_path);
}

void open_and_check_dir(char *filename,cmd_format_specifier *format_specifier , char *full_path){
    char *dir_path = format_specifier->path;
     DIR *dr = opendir(dir_path);
    if (!dr) {
        fprintf(stderr, "No such file or directory\n");
        return ;
    }
    struct dirent *de;
    
    
    while ((de = readdir(dr)) != NULL) {
        
        if (strcmp(filename, de->d_name) == 0) {

            format_specifier->is_file = true;
            if (format_specifier->is_list_all_file) {
                print_file_stat(full_path, filename);
            } else {
                printf("%s",filename);
            }
            return ;
        }
    }
    fprintf(stderr, "No such file or directory\n");
}


void go_to_current_path(cmd_format_specifier *format_specifier) {
    filename = (char*) malloc(strlen((format_specifier->path) + 3) * sizeof(char));
    filename = format_specifier->path;
    get_current_working_directory();
    format_specifier->path = curr_working_dir;
    char *fullpath = (char *) malloc((strlen(curr_working_dir)+strlen(filename)+5) * sizeof(char));
    strcpy(fullpath, curr_working_dir);
    if (fullpath[strlen(fullpath)-1] != '/') {
        strcat(fullpath, "/");
    }
    strcat(fullpath, filename);
    strcat(fullpath, "\0");
    open_and_check_dir(filename, format_specifier, fullpath );
}


void print_only_dir_filenames(DIR *dr, cmd_format_specifier *format_specifier) {
    struct dirent *de;  // Pointer for directory entry
    //char *dname;
    //char full_path[1024];
    
    while ((de = readdir(dr)) != NULL) {
        if (!(format_specifier->show_hidden_file) &&
            (de->d_name[0] == '.' ||
            de->d_name[strlen(de->d_name)-1] == '~')) {
                continue;
        }
        printf("%s\n", de->d_name);
    }
}


void print_directory(DIR* dr, cmd_format_specifier *format_specifier) {
    struct dirent *de;  // Pointer for directory entry
    char *dname;
    char full_path[1024];
    
    while ((de = readdir(dr)) != NULL) {
        
        strcpy(full_path, format_specifier->path);
        dname = de->d_name;
        int len = (int)strlen(dname);
        strcat(full_path, "/");
        int ind =  (int)strlen(full_path);
        for (int i = 0; i < len; i++) {
            full_path[ind] = dname[i];
            ind++;
        }
        full_path[ind] = '\0';
        
        if (format_specifier->show_hidden_file != true) {
            if (dname[0] != '.' && dname[strlen(dname)-1] != '~') {
                print_file_stat(full_path, dname);
            }
        } else {
            print_file_stat(full_path, dname);
        }
    }
    return;
}

void set_initial_values(cmd_format_specifier* format_specifier) {
    format_specifier->is_list_all_file = false;
    format_specifier->is_directory = false;
    format_specifier->is_file = false;
    format_specifier->is_ls_command = false;
    format_specifier->show_hidden_file = false;
    format_specifier->is_valid_format = true;
    format_specifier->path = NULL;
}
    
    
bool is_a_Valid_Path(const char *path) {
    return true;
}

void print_file_stat(char full_path[1024], char * dname) {
    struct stat sb;

    if(stat(full_path, &sb) == -1) {
        //perror("stat");
        exit(EXIT_FAILURE);
    }
    char *file_permission_stat = (char *) malloc(FILE_PERM_SIZE * sizeof(char));
    for (int i = 0; i < FILE_PERM_SIZE; i++) {
        file_permission_stat[i] = '\0';
    }
    strcat(file_permission_stat, ((S_ISDIR(sb.st_mode)) ? "d" : "-"));
    strcat(file_permission_stat, ((sb.st_mode & S_IRUSR) ? "r" : "-"));
    strcat(file_permission_stat, ((sb.st_mode & S_IWUSR) ? "w" : "-"));
    strcat(file_permission_stat, ((sb.st_mode & S_IXUSR) ? "x" : "-"));
    strcat(file_permission_stat, ((sb.st_mode & S_IRGRP) ? "r" : "-"));
    strcat(file_permission_stat, ((sb.st_mode & S_IWGRP) ? "w" : "-"));
    strcat(file_permission_stat, ((sb.st_mode & S_IXGRP) ? "x" : "-"));
    strcat(file_permission_stat, ((sb.st_mode & S_IROTH) ? "r" : "-"));
    strcat(file_permission_stat, ((sb.st_mode & S_IWOTH) ? "w" : "-"));
    strcat(file_permission_stat, ((sb.st_mode & S_IXOTH) ? "x" : "-"));
    strcat(file_permission_stat, "\0");
    printf("%s",file_permission_stat);
    printf("%5ld", (long) sb.st_nlink);
    char * user_name = get_username_val(sb.st_uid);
    printf("%6s",user_name);
    char * grp_name = get_groupname_val(sb.st_gid);
    printf("%6s", grp_name);
    printf("%8lld",(long long) sb.st_size);
    char *temp = (char *)malloc(strlen(ctime(&sb.st_mtime) + 5) * sizeof(char));
    temp = ctime(&sb.st_mtime);
    temp[strlen(temp) - 1] = '\0';
    printf(" %s", temp);
    printf(" %s", dname);
    printf("\n");
    
}

char * get_username_val(uid_t uid) {
    struct passwd *pwd;
    pwd = getpwuid(uid);
    if(pwd == NULL) {
        perror("getpwuid");
    }
    return pwd->pw_name;
}

char * get_groupname_val(gid_t gid) {
    struct group *grp;
    grp = getgrgid(gid);
    if(grp == NULL) {
        perror("getgrpid");
    }
    return grp->gr_name;
}


void join_signal() {
    if (signal(SIGINT, signal_handler) == SIG_ERR) {
        exit(EXIT_SUCCESS);
    }
}

void signal_handler(int signo) {
    if (signo == SIGINT) {
        psignal(signo, "Child terminated myls due to");
        exit(0);
    }
}




